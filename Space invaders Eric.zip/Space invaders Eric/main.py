import pygame
import random
import os# copied thie import os and the line under it from ai have isues loadeing it tough I possibly forgot

os.chdir(os.path.dirname(__file__))#ai line
pygame.init()
pygame.mixer.init()

# Screen
WIDTH = 800
HEIGHT = 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Space Invaders Simple")

# Load sounds and sprites
player_img = pygame.image.load("player.png")
enemy_img = pygame.image.load("enemy.png")
player_img = pygame.transform.scale(player_img, (60, 60))
enemy_img = pygame.transform.scale(enemy_img, (60, 60))

laser_sound = pygame.mixer.Sound("laser.wav")

# Player
player_x = WIDTH // 2
player_y = HEIGHT - 70
player_speed = 6

# Enemies (start with 1)
enemies = [
    [random.randint(50, WIDTH - 50), 100, 3]
]

# Bullets
bullets = []
bullet_speed = 10

# Score
score = 0
font = pygame.font.Font(None, 36)

clock = pygame.time.Clock()
running = True

while running:

    clock.tick(60)

    # Events
    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                bullets.append([player_x, player_y])
                laser_sound.play()

    # Player movement
    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT]:
        player_x -= player_speed

    if keys[pygame.K_RIGHT]:
        player_x += player_speed

    # Keep player on screen
    player_x = max(30, min(WIDTH - 30, player_x))

    # Move enemies
    for enemy in enemies:
        enemy[0] += enemy[2]

        if enemy[0] <= 30 or enemy[0] >= WIDTH - 30:
            enemy[2] *= -1
            enemy[1] += 20

    # Move bullets
    for bullet in bullets[:]:
        bullet[1] -= bullet_speed

        if bullet[1] < 0:
            bullets.remove(bullet)

    # Collision detection
    for bullet in bullets[:]:
        for enemy in enemies[:]:

            if (
                enemy[0] - 30 < bullet[0] < enemy[0] + 30
                and enemy[1] - 30 < bullet[1] < enemy[1] + 30
            ):

                bullets.remove(bullet)
                enemies.remove(enemy)
                score += 1

                # Spawn 2 new enemies
                for _ in range(2):
                    enemies.append([
                        random.randint(50, WIDTH - 50),
                        100,
                        random.choice([-3, 3])
                    ])

                break

    # Draw
    screen.fill((0, 0, 0))

    # Player
    screen.blit(player_img, (player_x - 30, player_y - 30))

    # Enemies
    for enemy in enemies:
        screen.blit(enemy_img, (enemy[0] - 30, enemy[1] - 30))

    # Bullets (simple)
    for bullet in bullets:
        pygame.draw.rect(
            screen,
            (255, 255, 0),
            (bullet[0] - 2, bullet[1] - 10, 4, 12)
        )

    # Score
    text = font.render("Score: " + str(score), True, (255, 255, 255))
    screen.blit(text, (10, 10))

    pygame.display.update()

pygame.quit()