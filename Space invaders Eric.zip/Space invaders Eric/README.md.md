This is a simple space invader game where you shoot alien invaders
press space to shoot and press left and arrow keys to go left and right 
and finally things can get pretty messy after you play for a while good luck and have fun

How to run
open the main file and then run it in a python environment
